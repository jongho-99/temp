const no = location.href.split("/").pop();

function selectOne(no) {
    

    const url = `http://127.0.0.1:8080/api/board/${no}`

    fetch(url)
    .then(resp => resp.json())
    .then(map => {

        const title = document.querySelector("input[name=title]")
        const content = document.querySelector("textarea[name=content]")

        const data = map.data;
        const status = map.status;

        if(data != null) {
            alert(status)
            title.value = data.title;
            content.value = data.content;
        } else {
            alert(status)
        }
    })
}

selectOne(no)

function update() {
    const no = location.href.split("/").pop();
    const title = document.querySelector("input[name=title]").value;
    const content = document.querySelector("textarea[name=content]").value;
    
    const vo = {
        no,
        title,
        content
    }

    const url = "http://127.0.0.1:8080/api/board"

    const option = {
        method : "PUT",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url,option)
    .then(resp => resp.json())
    .then(map => {

        const data = map.data;
        const status = map.status;

        if(data != 1) {
            alert(status);
        } else {
            alert(status);
        }
    })
}

function del() {
    const no = location.href.split("/").pop();
    const title = document.querySelector("input[name=title]").value;
    const content = document.querySelector("textarea[name=content]").value;
    
    const vo = {
        no,
        title,
        content
    }

    const url = "http://127.0.0.1:8080/api/board"

    const option = {
        method : "DELETE",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url,option)
    .then(resp => resp.json())
    .then(map => {

        const data = map.data;
        const status = map.status;

        if(data != 1) {
            alert(status);
        } else {
            alert(status);
        }
    })

}