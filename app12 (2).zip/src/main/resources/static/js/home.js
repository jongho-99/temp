function memberList() {

    const tb = document.querySelector("#tb");

    const url = "http://127.0.0.1:8080/api/member"

    fetch(url)
    .then(resp => resp.json())
    .then(map => {

        const data = map.data;
        const status = map.status;

        if(data != null) {

            tb.innerHTML = "";
            for(let i of data) {

                tb.innerHTML += `
                <tr>
                    <td>${i.no}</td>
                    <td>${i.userId}</td>
                    <td>${i.userPwd}</td>
                    <td>${i.userNick}</td>
                    <td>${i.createdDate}</td>
                </tr>
                `
            }
        } else {
            alert(status);
        }
    })
}