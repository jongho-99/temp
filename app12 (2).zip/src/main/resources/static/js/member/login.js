function login() {

    const userId = document.querySelector("input[name=userId]").value;
    const userPwd = document.querySelector("input[name=userPwd]").value;

    const vo = {
        userId,
        userPwd
    }

    const url = "http://127.0.0.1:8080/api/member/login"

    const option = {
        method : "POST",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option) 
    .then(resp => resp.json())
    .then(map => {

        const data = map.data;
        const status = map.status;

        if(data == null) {
            alert("로그인실패에요 ㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠㅠ");
        } else {
            alert(`${data.userNick}님 반가워여 !!!!!!!!!!! `);
            location.href = "http://127.0.0.1:8080/home"
        }
    })


}