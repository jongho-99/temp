package com.kh.app12.board;


import com.kh.app12.member.MemberVo;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.apache.ibatis.annotations.Delete;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {

    private final BoardService boardService;

    @PostMapping()
    public Map<String, Object> insert(@RequestBody BoardVo vo, HttpSession ss) {
        System.out.println(vo);
        MemberVo memberVo = (MemberVo) ss.getAttribute("loginUser");
        vo.setWriterNo(memberVo.getNo());
        int result = boardService.insert(vo);

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("data", result);
        if(result != 1) {
            map.put("status", "insert fail...");
        } else {
            map.put("status", "insert ok~~~~~~~");
        }

        return map;
    }

    @GetMapping()
    public Map<String, Object> list() {

        List<BoardVo> voList = boardService.list();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("data", voList);
        if(voList == null) {
            map.put("status", "list fail...");
        } else {
            map.put("status", "list ok~~~~~~~");
        }
        return map;
    }

    //상세페이지
    @GetMapping("{no}")
    public Map<String, Object> detail(@PathVariable String no) {

        BoardVo vo = boardService.detail(no);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("data", vo);
        if(vo == null) {
            map.put("status", "detail fail...");
        } else {
            map.put("status", "detail ok~~~~~~~");
        }
        return map;
    }

    @PutMapping()
    public Map<String, Object> update(@RequestBody BoardVo vo) {

        int result = boardService.update(vo);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("data", result);
        if(result != 1) {
            map.put("status", "update fail...");
        } else {
            map.put("status", "update ok~~~~~~~");
        }
        return map;
    }

    @DeleteMapping()
    public Map<String, Object> delete(@RequestBody BoardVo vo) {

        int result = boardService.delete(vo);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("data", result);
        if(result != 1) {
            map.put("status", "delete fail...");
        } else {
            map.put("status", "delete ok~~~~~~~");
        }
        return map;
    }


}
