package com.kh.app12.member;


import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import oracle.jdbc.proxy.annotation.Post;
import org.apache.ibatis.annotations.Delete;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/member")
@RequiredArgsConstructor
public class MemberApiController {

    private final MemberService memberService;

    @PostMapping("login")
    private Map<String, Object> login(@RequestBody MemberVo vo, HttpSession ss) {

        MemberVo userVo = memberService.login(vo);

        ss.setAttribute("loginUser", userVo);

        Map<String, Object> map = new HashMap<String, Object>();

        map.put("data", userVo);
        map.put("status", "login success!!!!!!");

        return map;
    }

    @PostMapping("join")
    private Map<String, Object> join(@RequestBody MemberVo vo) {

        int result = memberService.join(vo);

        Map<String, Object> map = new HashMap<>();

        map.put("data", result);
        map.put("status", "join success!!!!");

        return map;
    }

    @GetMapping()
    private Map<String, Object> list() {

        List<MemberVo> voList = memberService.list();

        Map<String, Object> map = new HashMap<>();

        map.put("data", voList);
        map.put("status", "userlist success!!!!");

        return map;
    }



    //mypage
    @GetMapping("mypage")
    private Map<String, Object> selectOne(@RequestParam String no) {

        MemberVo userVo = memberService.selectOne(no);

        Map<String, Object> map = new HashMap<>();

        map.put("data", userVo);
        map.put("status", "selectOne success!!!!");

        return map;
    }

    @PutMapping()
    private Map<String, Object> update(@RequestBody MemberVo vo) {

        int result = memberService.update(vo);

        Map<String, Object> map = new HashMap<>();

        map.put("data", result);
        map.put("status", "update success!!!!");

        return map;
    }

    @DeleteMapping()
    private Map<String, Object> delete(@RequestParam String no) {

        int result = memberService.delete(no);

        Map<String, Object> map = new HashMap<>();

        map.put("data", result);
        map.put("status", "delete success!!!!");

        return map;
    }
}
