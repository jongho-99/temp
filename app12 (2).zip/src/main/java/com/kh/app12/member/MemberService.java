package com.kh.app12.member;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class MemberService {

    private final MemberMapper memberMapper;

    public MemberVo login(MemberVo vo) {
        return memberMapper.login(vo);
    }

    public int join(MemberVo vo) {
        return memberMapper.join(vo);
    }

    public List<MemberVo> list() {
        return memberMapper.list();
    }

    public MemberVo selectOne(String no) {
        return memberMapper.selectOne(no);
    }

    public int delete(String no) {
        return memberMapper.delete(no);
    }

    public int update(MemberVo vo) {
        return memberMapper.update(vo);
    }
}
