package com.kh.app12.member;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface MemberMapper {

    @Select("""
            SELECT
                NO
                ,USER_ID
                ,USER_PWD
                ,USER_NICK
                ,CREATED_DATE
                ,DEL_YN
            FROM MEMBER
            WHERE USER_ID = #{userId}
            AND USER_PWD = #{userPwd}
            AND DEL_YN = 'N'
            """)
    public MemberVo login(MemberVo vo);

    @Insert("""
            INSERT INTO MEMBER
            (
                NO
                ,USER_ID
                ,USER_PWD
                ,USER_NICK
            )
            VALUES
            (
                SEQ_MEMBER.NEXTVAL
                , #{userId}
                , #{userPwd}
                , #{userNick})
            """)
    int join(MemberVo vo);

    @Select("""
            SELECT
                NO
                ,USER_ID
                ,USER_PWD
                ,USER_NICK
                ,CREATED_DATE
                ,DEL_YN
            FROM MEMBER
            WHERE DEL_YN = 'N'
            """)
    List<MemberVo> list();

    @Select("""
            SELECT
                NO
                ,USER_ID
                ,USER_PWD
                ,USER_NICK
                ,CREATED_DATE
                ,DEL_YN
            FROM MEMBER
            WHERE NO = #{no}
            AND DEL_YN = 'N'
            """)
    MemberVo selectOne(String no);

    @Update("""
            UPDATE MEMBER
                SET
                    DEL_YN = 'Y'
                WHERE NO = #{no}
            """)
    int delete(String no);


    @Update("""
            UPDATE MEMBER
                SET
                    USER_PWD = #{userPwd}
                    , USER_NICK = #{userNick}
                WHERE NO = #{no}
                AND DEL_YN = 'N'
            """)
    int update(MemberVo vo);
}
