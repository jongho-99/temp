function login() {
    
    const id = document.querySelector("input[name=userId]").value;
    const pwd = document.querySelector("input[name=userPwd]").value;

    const vo = {
        id,
        pwd
    }

    const url = "http://127.0.0.1:8080/api/member/login"

    const option = {
        method : "POST",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option)
    .then(resp => {
        if(resp.status == '404') {
            alert("로그인실패입니다" + resp.status);
            throw new Error();
        }
        return resp.json();
    })
    .then(data => {

        if(data) {
            alert("로그인 성공이에여!!!")
            location.href="http://127.0.0.1:8080/home";
        } 
    }).catch(err => {

        log(err);
    }) 

    
}