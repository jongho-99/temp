function join() {

    const id = document.querySelector("input[name=userId]").value;
    const pwd = document.querySelector("input[name=userPwd]").value;
    const nick = document.querySelector("input[name=userNick]").value;

    const url = "http://127.0.0.1:8080/api/member"

    const vo = {

        id,
        pwd,
        nick
    }

    const option = {
        method : "POST",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option)
    .then(resp => {
        alert(resp.status);
        return resp.json();
    })
    .then(data => {
        
        if(data == 1) {
            alert("회원가입 성공이에여!!!!")
            location.href = "http://127.0.0.1:8080/member/login"
        } else {
            alert("회원가입 실패에여 ㅠㅠㅠ")
        }
        
    })
}