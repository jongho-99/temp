function join() {

    const id = document.querySelector("input[name=userId]").value;
    const pwd = document.querySelector("input[name=userPwd]").value;
    const nick = document.querySelector("input[name=userNick]").value;

    const f = document.querySelector("input[name=f]")
    //프로필 이미지 객체를 얻음
    const file = f.files[0];

    const url = "http://127.0.0.1:8080/api/member"

    const fd = new FormData();
    fd.append("id", id);
    fd.append("pwd", pwd);
    fd.append("nick", nick);
    fd.append("f", file);

    const option = {
        method : "POST",
        //application/json 대신 multipart/form-data 적어도 되고 안적어도 되고
        headers : {},
        body : fd
    }

    fetch(url, option)
    .then(resp => {
        alert(resp.status);
        return resp.json();
    })
    .then(data => {
        
        if(data == 1) {
            alert("회원가입 성공이에여!!!!")
            location.href = "http://127.0.0.1:8080/member/login"
        } else {
            alert("회원가입 실패에여 ㅠㅠㅠ")
        }
        
    })
}

function showPreview() {

    const x = document.querySelector("input[name=f]");
    const preview = document.querySelector("#profile-preview");

    const file = x.files[0];

   
    
    const fr = new FileReader();
    fr.readAsDataURL(file);

    // fr.onload = () => {
    //     preview.src = e.targer.result;
    // } 

    fr.addEventListener("load", (e) => {
        preview.src = e.target.result;
    });
    
    
}

