function mypage() {

    const userId = document.querySelector("input[name=userId]");
    const userPwd = document.querySelector("input[name=userPwd]");
    const userNick = document.querySelector("input[name=userNick]");


    const url = "http://127.0.0.1:8080/api/member"

    fetch(url)
    .then(resp => resp.json())
    .then(data => {

        userId.value = data.id;
        userNick.value = data.nick;
    })
}

mypage();


function update() {
    
    const id = document.querySelector("input[name=userId]");
    const pwd = document.querySelector("input[name=userPwd]").value;
    const nick = document.querySelector("input[name=userNick]").value;

    const vo = {
        pwd,
        nick
    }

    const url = "http://127.0.0.1:8080/api/member"

    const option = {
        method : "PUT",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option)
    .then(resp => resp.json())
    .then(data => {

        if(data) {
            alert("수정되었습니당 !!!");;
        } else {
            alert("수정 실패에여 ㅠㅠ");
        }
    })
}

function quit() {

    const isReal = confirm("정말 탈퇴하시겠습니까???")

    if(!isReal) {return};

    const id = document.querySelector("input[name=userId]").value;

    const url ="http://127.0.0.1:8080/api/member"

    const option = {
        method : "DELETE",
        headers : {"Content-Type": "text/plain"},
        body : id
    }

    fetch(url, option) 
    .then(resp => resp.json())
    .then(data => {

        if(data) {
            alert("회원탈퇴 되었습니다!!!")
            localStorage.href = "/home"
        } else {
            alert("회원탈퇴 실패입니당 ㅠㅠ");
        }
    })

}

function checkCurrentPwd() {
    const oldPwd = document.querySelector("input[name=oldPwd]").value;
    
    return oldPwd.length > 0;
}

function checkSamePwd() {

    const newPwd = document.querySelector("input[name=newPwd]").value;
    const newPwdCheck = document.querySelector("input[name=newPwdCheck]").value;

    return newPwd === newPwdCheck;
}

function edit() {
    const checkResult = document.querySelector("#newPwdCheckResult");
    const pwdCheckResult = checkCurrentPwd();
    if(!pwdCheckResult) {
        checkResult.classList.add("color-red");
        checkResult.innerHTML = "현재 비밀번호를 입력하세요";
        return;
    }

    const isSame = checkSamePwd();
    if(!isSame) {
        checkResult.innerHTML = "일치하게 적어주세요";
        checkResult.classList.add("color-red");
        return;
    }
    const pwd = document.querySelector("input[name=oldPwd]").value;
    const newPwd = document.querySelector("input[name=newPwd]").value;
    const nick = document.querySelector("input[name=userNick]").value;
    const file = document.querySelector("input[name=f]").files[0];


    const fd = new FormData();
    fd.append("pwd", pwd);
    fd.append("newPwd", newPwd);
    fd.append("nick", nick);
    fd.append("f", file)

    const url = "http://127.0.0.1:8080/api/member"

    const option = {
        method : "PUT",
        headers : {},
        body : fd
    }

    fetch(url, option)
    .then(resp => resp.json())
    .then(data => {

        if(data) {
            alert("수정되었습니당 !!!");
            location.href = "/home";
        } else {
            alert("수정 실패에여 ㅠㅠ");
        }
    })
}


function showPreview() {

    const x = document.querySelector("input[name=f]");
    const preview = document.querySelector("#profile-preview");

    const file = x.files[0];

   
    
    const fr = new FileReader();
    fr.readAsDataURL(file);

    // fr.onload = () => {
    //     preview.src = e.targer.result;
    // } 

    fr.addEventListener("load", (e) => {
        preview.src = e.target.result;
    });
    
}