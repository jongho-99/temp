function mypage() {

    const userId = document.querySelector("input[name=userId]");
    const userPwd = document.querySelector("input[name=userPwd]");
    const userNick = document.querySelector("input[name=userNick]");


    const url = "http://127.0.0.1:8080/api/member"

    fetch(url)
    .then(resp => resp.json())
    .then(data => {

        userId.value = data.id;
        userPwd.value = data.pwd;
        userNick.value = data.nick;
    })
}

mypage();


function update() {
    
    const id = document.querySelector("input[name=userId");
    const pwd = document.querySelector("input[name=userPwd").value;
    const nick = document.querySelector("input[name=userNick").value;

    const vo = {
        pwd,
        nick
    }

    const url = "http://127.0.0.1:8080/api/member"

    const option = {
        method : "PUT",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option)
    .then(resp => resp.json())
    .then(data => {

        if(data) {
            alert("수정되었습니당 !!!");;
        } else {
            alert("수정 실패에여 ㅠㅠ");
        }
    })
}

function quit() {

    const id = document.querySelector("input[name=userId]").value;

    const url ="http://127.0.0.1:8080/api/member"

    const option = {
        method : "DELETE",
        headers : {"Content-Type": "text/plain"},
        body : id
    }

    fetch(url, option) 
    .then(resp => resp.json())
    .then(data => {

        if(data) {
            alert("회원탈퇴 되었습니다!!!")
        } else {
            alert("회원탈퇴 실패입니당 ㅠㅠ");
        }
    })

}