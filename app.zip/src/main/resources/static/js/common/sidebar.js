document.querySelectorAll('#layout > .sidebar > nav > ul > li > a').forEach(aTag => {
    aTag.addEventListener('mouseover', function() {
        this.parentNode.classList.toggle('active');
    });
});
