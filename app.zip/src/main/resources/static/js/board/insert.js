function insert() {

    const title = document.querySelector("input[name=title]").value;
    const content = document.querySelector("textarea[name=content]").value;
    const ctgrNo = document.querySelector("select[name=categoryNo]").value;
    
    const fd = new FormData();

    fd.append("title", title);
    fd.append("content", content);
    fd.append("categoryNo", ctgrNo);

    const url = "http://127.0.0.1:8080/api/board"

    const option = {

        method : "POST",
        body : fd
    }

    fetch(url,option)
    .then(resp => {
        alert(resp.status);
        return resp.json();
    })
    .then(data => {

        if(data == 1) {
            alert("글 작성이 완료됐어여!!!!!!");
            location.href = "http://127.0.0.1:8080/board/list"
        } else {
            alert("글 작성에 실패했어여 ㅠㅠㅠ");
            // location.reload();
        }

    })

    return false;


    

    
}