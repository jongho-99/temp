const no = location.href.split("/").pop();
function detail(no) {


    const url = `http://127.0.0.1:8080/api/board/${no}`

    fetch(url)
    .then(resp => resp.json())
    .then(vo => {

        const no = document.querySelector("#no");
        const hit = document.querySelector("#hit");
        const title = document.querySelector("input[name=title]");
        const content = document.querySelector("textarea[name=content]");

        no.innerText = "게시물 번호: " + vo.no + " / ";
        hit.innerText = "조회수: "+ vo.hit;
        title.value = vo.title;
        content.value = vo.content;


    })

}

detail(no);