const no = location.href.split("/").pop();
function detail(no) {


    const url = `http://127.0.0.1:8080/api/board/${no}`

    fetch(url)
    .then(resp => resp.json())
    .then(vo => {

        const no = document.querySelector("#no");
        const hit = document.querySelector("#hit");
        const title = document.querySelector("input[name=title]");
        const content = document.querySelector("textarea[name=content]");

        no.innerText = "게시물 번호: " + vo.no + " / ";
        hit.innerText = "조회수: "+ vo.hit;
        title.value = vo.title;
        content.value = vo.content;


    })

}

detail(no);


function update() {

    const url = "http://127.0.0.1:8080/api/board"

    option = {
        method : "PUT",
        headers : {},
    
    }

    fetch(url, option)
    .then(resp => resp.json())
    .then(result => {

        if(result == 1) {
            alert("수정되었어여 !!!!");
        }  else {
            alert("수정 실패에여 ㅠㅠㅠ");
        }
    })
}

function del() {

    const url = "http://127.0.0.1:8080/api/board"

    option = {
        method : "DELETE",
        headers : {},

    }

    fetch(url, option)
    .then(resp => resp.json())
    .then(result => {

        if(result == 1) {
            alert("삭제 되었어여 !!!!");
        }  else {
            alert("삭제 실패에여 ㅠㅠㅠ");
        }
    })
}

function replyInsert() {

    const content = document.querySelector("textarea[name=cmt]").value;
    const refNo = location.href.split("/").pop();

    const url ="http://127.0.0.1:8080/api/board/replyInsert";

    const vo = {
        refNo,
        content
    }

    const option = {
        method : "POST",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option)
    .then(resp => {
        if(!resp.ok) {
            throw new Error();
        }
        return resp.json();

    })
    .then(result => {

        if(result != 1) {
            alert("댓글 작성 실패입니당 ㅠㅠ");
        } else {
            alert("댓글 작성 성공입니다.");
            location.reload();
        }
    })
}

function replyList() {

    const url="http://127.0.0.1:8080/api/board/replyList";
    const refNo = location.href.split("/").pop();
    const vo = {
        refNo
    }

    const option = {

        method : "POST",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
        
    }

    fetch(url,option)
    .then(resp => {
        if(!resp.ok) {
            throw new Error();
        }
        return resp.json();
    })
    .then(data => {

        if(data == null) {
            alert("리스트 출력 실패에여 ㅠㅠ");
        } else {

            const tb = document.querySelector("#tb");
            for(let i of data) {
                tb.innerHTML = `
                <tr>
                    <td>${i.writerNo}</td>
                    <td>${i.content}</td>
                </tr>
                
                `

            }

        }
    })
}
replyList();