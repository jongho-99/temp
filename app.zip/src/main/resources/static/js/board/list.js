function list() {

    const url = "http://127.0.0.1:8080/api/board"

    fetch(url)
    .then(resp => resp.json())
    .then(data => {

        
        const tb =  document.querySelector("#tb");
        tb.innerHTML = "";  
        for(let i of data) {
            tb.innerHTML += `
            <tr onclick="location.href='http://127.0.0.1:8080/board/detail/${i.no}'">
                <td>${i.no}</td>
                <td>${i.title}</td>
                <td>${i.writerNo}</td>
                <td>${i.hit}</td>
            </tr>
        `
        }
    })
}

list();