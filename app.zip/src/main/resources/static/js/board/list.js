function list() {
    const pno = location.href.split("=").pop();
    const url = `http://127.0.0.1:8080/api/board?page=${pno}`

    fetch(url)
    .then(resp => resp.json())
    .then(map => {

        const voList = map.voList;
        const pvo = map.pvo;

        const tb =  document.querySelector("#tb");
        tb.innerHTML = "";  
        for(let i of voList) {
            tb.innerHTML += `
            <tr onclick="location.href='http://127.0.0.1:8080/board/detail/${i.no}'">
                <td>${i.categoryNo}</td>
                <td>${i.no}</td>
                <td>${i.title}</td>
                <td>${i.writerNo}</td>
                <td>${i.hit}</td>
            </tr>
        `
        }

        const pageAreaDiv = document.querySelector("#page-area");
        let pageStr = "";
        if(pvo.startPage != 1) 
            pageStr += `<button onclick="location.href='/board/list/?page=${pvo.startPage-1}'">이전</button>`

        for(let i = pvo.startPage; i <= pvo.endPage; ++i) {
            pageStr += `<button onclick="location.href='/board/list/?page=${i}'">${i}</button>`
            
        }

        if(pvo.endPage != pvo.maxPage) 
            pageStr += `<button onclick="location.href='/board/list/?page=${pvo.endPage+1}'">다음</button>`

        pageAreaDiv.innerHTML = pageStr;
    })
}

list();