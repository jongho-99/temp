package com.swy.app.util.file;

import com.swy.app.member.vo.MemberVo;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class FileUploader {

    public static String save(MultipartFile f, String dirPath) throws IOException {

        if(f == null) {
            return "xxxxxx.png";
        }

        //input 파일 받아와서 서버에 저장
        String[] extArr = f.getOriginalFilename().split("\\.");
        //originName = f.getOriginalFilename();
        //String ext = originName.substring(originName.lastIndexOf("."));
        String ext = "." + extArr[extArr.length - 1];
        String changeName = System.currentTimeMillis() + UUID.randomUUID().toString() + ext;
        String savePath = dirPath + changeName;
        File targetFile = new File(savePath);
        f.transferTo(targetFile);


        return changeName;
    }
}
