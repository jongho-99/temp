package com.swy.app.board.vo;

import lombok.Data;

@Data
public class ReplyVo {

    private String no;
    private String content;
    private String refNo;
    private String writerNo;
    private String createDate;
    private String delYn;

}
