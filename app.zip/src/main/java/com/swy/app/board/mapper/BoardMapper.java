package com.swy.app.board.mapper;

import com.swy.app.board.vo.BoardVo;
import com.swy.app.board.vo.ReplyVo;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface BoardMapper {

    @Insert("""
            INSERT INTO BOARD
            (
                NO
                ,TITLE
                ,CONTENT
                ,CATEGORY_NO
                ,WRITER_NO
            )
            VALUES
            (
                SEQ_BOARD.NEXTVAL
                , #{title}
                , #{content}
                , '1'
                , #{writerNo}
            )
            """)
    int insert(BoardVo vo);


    @Select("""
            SELECT *
            FROM BOARD
            WHERE DEL_YN = 'N'
            ORDER BY NO DESC
            """)
    List<BoardVo> list();

    @Select("""
            SELECT *
            FROM BOARD
            WHERE DEL_YN = 'N' AND NO = #{no}
            ORDER BY NO DESC
            """)
    BoardVo detail(String no);

    @Update("""
            UPDATE BOARD
                SET
                    TITLE = #{title}
                    , CONTENT = #{content}
                WHERE NO = 1
                AND DEL_YN = 'N'
            """)
    int update(BoardVo vo);

    @Update("""
            UPDATE BOARD
                SET
                    DEL_YN = 'Y'
                WHERE NO = #{no}
            """)
    int delete(BoardVo vo);

    @Update("""
            UPDATE BOARD
                SET
                    HIT = HIT + 1
                WHERE NO = #{no}
            """)
    int increaseHit(String no);

    @Insert("""
             INSERT INTO BOARD_REPLY
            (
                NO
                ,CONTENT
                ,REF_NO
                ,WRITER_NO
            )
            VALUES
            (
                SEQ_REPLY.NEXTVAL
                , #{content}
                , #{refNo}
                , #{writerNo}
            )
            """)
    int replyInsert(ReplyVo vo);


    @Select("""
            SELECT * FROM BOARD_REPLY WHERE REF_NO = #{refNo} ORDER BY NO DESC
            """)
    List<ReplyVo> replyList(ReplyVo vo);
}
