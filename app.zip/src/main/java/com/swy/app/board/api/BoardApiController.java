package com.swy.app.board.api;

import com.swy.app.board.service.BoardService;
import com.swy.app.board.vo.BoardVo;
import com.swy.app.board.vo.CategoryVo;
import com.swy.app.board.vo.ReplyVo;
import com.swy.app.member.vo.MemberVo;
import com.swy.app.util.page.PageVo;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {

    private final BoardService boardService;

    @PostMapping
    public ResponseEntity<Integer> insert(BoardVo vo, HttpSession ss, List<MultipartFile> f) {

        MemberVo loginUser = (MemberVo) ss.getAttribute("loginUser");
        vo.setWriterNo(loginUser.getNo());

        System.out.println("vo = " + vo);
//        vo.setFileList(fileList);
        int result = boardService.insert(vo);

        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.internalServerError().body(result);
        }

    }

    @GetMapping()
    private ResponseEntity<Map<String, Object>> list(@RequestParam int page) {

        int listCount = boardService.getBoardCnt();
        int pageLimit = 5;
        int boardLimit = 10;

        PageVo pvo = new PageVo(listCount, page, pageLimit, boardLimit);

        List<BoardVo> voList = boardService.list(pvo);

        Map<String, Object> map = new HashMap<>();
        map.put("voList", voList);
        map.put("pvo", pvo);

        System.out.println("pvo = " + pvo);
        System.out.println("voList = " + voList);
        if(voList != null) {
            return ResponseEntity.ok().body(map);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("{no}")
    private ResponseEntity<BoardVo> detail(@PathVariable String no) {

        BoardVo vo = boardService.detail(no);

        if(vo != null) {
            return ResponseEntity.ok().body(vo);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping
    private ResponseEntity<Integer> update(@RequestBody BoardVo vo) {

        int result = boardService.update(vo);

        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping
    private ResponseEntity<Integer> delete(@RequestBody BoardVo vo) {

        int result = boardService.delete(vo);

        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("replyInsert")
    private ResponseEntity<Integer> replyInsert(@RequestBody ReplyVo vo, HttpSession ss) {

        MemberVo loginUser = (MemberVo) ss.getAttribute("loginUser");
        String writerNo = loginUser.getNo();
        vo.setWriterNo(writerNo);
        int result = boardService.replyInsert(vo);

        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("replyList")
    private ResponseEntity<List<ReplyVo>> replyList(@RequestBody ReplyVo vo) {

        List<ReplyVo> voList = boardService.replyList(vo);

        if(voList == null) {
            return ResponseEntity.badRequest().build();
        } else {
            return ResponseEntity.ok().body(voList);
        }

    }

    @GetMapping("category")
    private ResponseEntity<List<CategoryVo>> cateList() {

        List<CategoryVo> voList = boardService.cateList();

        if(voList == null) {
            return ResponseEntity.badRequest().build();
        } else {
            return ResponseEntity.ok().body(voList);
        }
    }

}
