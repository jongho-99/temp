package com.swy.app.board.api;

import com.swy.app.board.service.BoardService;
import com.swy.app.board.vo.BoardVo;
import com.swy.app.member.vo.MemberVo;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {

    private final BoardService boardService;

    @PostMapping
    public ResponseEntity<Integer> insert(@RequestBody BoardVo vo, HttpSession ss) {

        MemberVo loginUser = (MemberVo) ss.getAttribute("loginUser");
        vo.setWriterNo(loginUser.getNo());
        int result = boardService.insert(vo);

        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();
        }

    }

    @GetMapping
    private ResponseEntity<List<BoardVo>> list() {

        List<BoardVo> voList = boardService.list();

        if(voList != null) {
            return ResponseEntity.ok().body(voList);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("{no}")
    private ResponseEntity<BoardVo> detail(@PathVariable String no) {

        BoardVo vo = boardService.detail(no);

        if(vo != null) {
            return ResponseEntity.ok().body(vo);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }
}
