package com.swy.app.board.vo;

import lombok.Data;

@Data
public class CategoryVo {

    private String no;
    private String name;

}
