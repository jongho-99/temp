package com.swy.app.board.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("board")
public class BoardController {

    @GetMapping("insert")
    public String insert(HttpSession ss) {

        if(ss.getAttribute("loginUser") != null) {

            return "/board/insert";
        } else {
            ss.setAttribute("msg","로그인이 필요합니다");
            return "redirect:/member/login";
        }
    }

    @GetMapping("list/*")
    public String list() {
        return "board/list";
    }

    @GetMapping("detail/*")
    public String detail() {
        return "board/detail";
    }
}
