package com.swy.app.board.service;

import com.swy.app.board.mapper.BoardMapper;
import com.swy.app.board.vo.BoardVo;
import com.swy.app.board.vo.CategoryVo;
import com.swy.app.board.vo.ReplyVo;
import com.swy.app.util.page.PageVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class BoardService {

    private final BoardMapper boardMapper;
    public int insert(BoardVo vo) {
        return boardMapper.insert(vo);
    }

    public List<BoardVo> list(PageVo vo) {
        return boardMapper.list(vo);
    }

    public BoardVo detail(String no) {
        boardMapper.increaseHit(no);
        return boardMapper.detail(no);
    }

    public int update(BoardVo vo) {
        return boardMapper.update(vo);
    }

    public int delete(BoardVo vo) {
        return boardMapper.delete(vo);
    }

    public int replyInsert(ReplyVo vo) {
        return boardMapper.replyInsert(vo);
    }

    public List<ReplyVo> replyList(ReplyVo vo) {
        return boardMapper.replyList(vo);
    }

    public List<CategoryVo> cateList() {
        return boardMapper.cateList();
    }

    public int getBoardCnt() {
        return boardMapper.getBoardCnt();
    }

//    public inventoryVo deductStock(int productId, int requestQty) {
//
//        // 프로덕트 아이디 그리고 필요량 비즈니스 로직 처리
//        // private final InvMapper invMapper;
//        List<inventoryVo> voList= invMapper.findByProductIdOrderByExp(productId);
//
//        // voList = 해당 제품 + 소비기한 리스트
//        int requestAmount = requestQty;
//        //for문을 통해서 inventoryVo vo 하나씩 빼내면서, 요구량(requestAmount)이 작아질 때 까지
//        for(inventoryVo vo : voList) {
//            if(requestAmount < vo.current_quantity) {
//                // invMapper.updateQuantityByInventoryId(vo, requestAmount);
//                break;
//            } else {
//                // invMapper.deleteInventoryColumn(vo);
//            }
//        }

}

