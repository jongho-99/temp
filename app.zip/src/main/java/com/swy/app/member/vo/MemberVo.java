package com.swy.app.member.vo;

import lombok.Data;

@Data
public class MemberVo {

   private String no;
   private String id;
   private String pwd;
   private String nick;
   private String del_yn;
   private String enroll_date;
   private String modify_date;
}
