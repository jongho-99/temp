package com.swy.app.member.service;

import com.swy.app.member.mapper.MemberMapper;
import com.swy.app.member.vo.MemberVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class MemberService {

    private final MemberMapper memberMapper;


    public int join(MemberVo vo) {
        return memberMapper.join(vo);

    }

    public MemberVo login(MemberVo vo) {
        return memberMapper.login(vo);
    }

    public int update(MemberVo vo) {
        return memberMapper.update(vo);
    }

    public int delete(String userId) {
        return memberMapper.delete(userId);
    }
}
