package com.swy.app.member.api;

import com.swy.app.member.service.MemberService;
import com.swy.app.member.vo.MemberVo;
import com.swy.app.util.file.FileUploader;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("api/member")
@RequiredArgsConstructor
public class MemberApiController {

    private final MemberService memberService;
    @Value("${upload.path.member}")
    private String profilePath;

    @Value("${upload.path.divPath}")
    private String divPath;

    @PostMapping
    private ResponseEntity<Integer> join(MemberVo vo, MultipartFile f) throws IOException {
        //input 파일 받아와서 서버에 저장
        //f를 설정안하면 기본 이미지를 보여주도록 (1)
        //properties 확장자는 키/밸류 형태를 가짐 경로를 밸류로하는 키로 처리가 가능

        if(f != null) {
            String changeName = FileUploader.save(f, divPath);
            vo.setProfile(changeName);
        } else {
            vo.setProfile("default.png");
        }


        int result = memberService.join(vo);
        Map<String, Object> map = new HashMap<>();
        map.put("data", result);
        System.out.println(ResponseEntity.status(HttpStatus.OK).body(result));
        if(result == 1) {
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }
    }

    @PostMapping("login")
    private ResponseEntity<MemberVo> login(@RequestBody MemberVo vo, HttpSession ss) {

        MemberVo userVo = memberService.login(vo);

        System.out.println(ResponseEntity.status(HttpStatus.OK).body(userVo));
        if(userVo != null) {

            userVo.setSavePath(profilePath + userVo.getProfile());

            ss.setAttribute("loginUser", userVo);
            return ResponseEntity.status(HttpStatus.OK).body(userVo);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(userVo);
        }


    }

    @GetMapping
    private ResponseEntity<MemberVo> mypage(HttpSession ss) {

        MemberVo userVo = (MemberVo) ss.getAttribute("loginUser");

        if(userVo != null) {
            return ResponseEntity.ok().body(userVo);
        } else {
            return ResponseEntity.badRequest().build();//404
        }
    }

    @PutMapping
    private ResponseEntity<Integer> update(MultipartFile f, MemberVo vo, HttpSession ss) throws IOException {
        MemberVo loginUser = (MemberVo) ss.getAttribute("loginUser");
        vo.setNo(loginUser.getNo());

        String changeName = FileUploader.save(f, divPath);
        vo.setProfile(changeName);

        int result = memberService.update(vo);

        if(result == 1) {
            ss.removeAttribute("loginUser");
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();//404
        }
    }

    @DeleteMapping
    private ResponseEntity<Integer> delete(@RequestBody String userId, HttpSession ss) {

        int result = memberService.delete(userId);

        ss.removeAttribute("loginUser");
        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }


}
