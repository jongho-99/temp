package com.swy.app.member.api;

import com.swy.app.member.service.MemberService;
import com.swy.app.member.vo.MemberVo;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("api/member")
@RequiredArgsConstructor
public class MemberApiController {

    private final MemberService memberService;

    @PostMapping
    private ResponseEntity<Integer> join(@RequestBody MemberVo vo) {

        int result = memberService.join(vo);

        Map<String, Object> map = new HashMap<>();

        map.put("data", result);

        System.out.println(ResponseEntity.status(HttpStatus.OK).body(result));
        if(result == 1) {
            return ResponseEntity.status(HttpStatus.OK).body(result);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(result);
        }


    }

    @PostMapping("login")
    private ResponseEntity<MemberVo> login(@RequestBody MemberVo vo, HttpSession ss) {

        MemberVo userVo = memberService.login(vo);

        System.out.println(ResponseEntity.status(HttpStatus.OK).body(userVo));
        if(userVo != null) {
            ss.setAttribute("loginUser", userVo);
            return ResponseEntity.status(HttpStatus.OK).body(userVo);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(userVo);
        }


    }

    @GetMapping
    private ResponseEntity<MemberVo> mypage(HttpSession ss) {

        MemberVo userVo = (MemberVo) ss.getAttribute("loginUser");

        if(userVo != null) {
            return ResponseEntity.ok().body(userVo);
        } else {
            return ResponseEntity.badRequest().build();//404
        }
    }

    @PutMapping
    private ResponseEntity<Integer> update(@RequestBody MemberVo vo, HttpSession ss) {
        MemberVo loginUser = (MemberVo) ss.getAttribute("loginUser");
        vo.setNo(loginUser.getNo());
        int result = memberService.update(vo);

        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();//404
        }
    }

    @DeleteMapping
    private ResponseEntity<Integer> delete(@RequestBody String userId) {

        int result = memberService.delete(userId);

        if(result == 1) {
            return ResponseEntity.ok().body(result);
        } else {
            return ResponseEntity.badRequest().build();
        }
    }

}
