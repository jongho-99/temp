package com.swy.app.member.controller;

import com.swy.app.member.vo.MemberVo;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("member")
public class MemberController {

    @GetMapping("join")
    public void join() {}

    @GetMapping("login")
    public void login() {}

    @GetMapping("mypage")
    public String mypage(HttpSession ss) {
        MemberVo loginVo = (MemberVo) ss.getAttribute("loginUser");

        if(loginVo != null) {
            return "member/mypage";
        } else {
            ss.setAttribute("msg", "로그인이 필요합니다.");
            return "redirect:/member/login";
        }
    }

    @GetMapping("logout")
    private String logout(HttpSession ss) {

        ss.removeAttribute("loginUser");
        ss.setAttribute("msg","로그아웃 되었습니다.");

        return "redirect:/home";
    }

}
