package com.kh.app07.member;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("member")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @GetMapping("join")
    public void join(){

    }

    @PostMapping("join")
    public String join(MemberVo vo, HttpSession ss) {
        try{
            int result = memberService.join(vo);
        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:error";
        }

        ss.setAttribute("alertMsg", "회원가입완료되었어여!!!!!!!!!");
        return "redirect:login";
    }

    @GetMapping("login")
    public void login(Model model, HttpSession ss) {
        String alertMsg = (String) ss.getAttribute("alertMsg");
        if(alertMsg != null) {
            model.addAttribute("alertMsg", alertMsg);
            ss.removeAttribute("alertMsg");
        }
    }

    @PostMapping("login")
    public String login(MemberVo vo, HttpSession ss) {
        try{
            MemberVo userVo = memberService.login(vo);

            if(userVo == null) {
                return "redirect:error";
            }

            ss.setAttribute("loginUser", userVo);
            ss.setAttribute("alertMsg", userVo.getUserId()+"님 환영해여!!!!!!!!!");
            return "redirect:/home";
        } catch (Exception e) {
            e.printStackTrace();
            return "redirect:error";
        }

    }

    @GetMapping("logout")
    public String logout(HttpSession ss) {
        ss.removeAttribute("loginUser");
        ss.setAttribute("alertMsg", "로그아웃되었어여!!!!!!!!!!!!!!!");
        return "redirect:/home";
    }

    @GetMapping("mypage")
    public String mypage(HttpSession ss) {
        if(ss.getAttribute("loginUser") == null) {
            ss.setAttribute("alertMsg", "로그인이 필요합니다");

            return "redirect:/login";
        };

        return "member/mypage";

    }


    @GetMapping("quit")
    public String quit(HttpSession ss) {
        try{
            int result = memberService.quit((MemberVo) ss.getAttribute("loginUser"));

            if(result != 1) {
               throw new IllegalStateException("[MEMBER-002] QUIT ERROR");
            }
            ss.removeAttribute("loginUser");
            ss.setAttribute("alertMsg", "회원탈퇴가 완료되었습니다.");
            return "redirect:/home";
        } catch(Exception e) {
            e.printStackTrace();
            return "redirect:error";
        }

    }

    @PostMapping("update")
    public String update(HttpSession ss, MemberVo vo) {
        try{
            System.out.println(vo);
            int result = memberService.update(vo);

            if(result != 1) {
                throw new IllegalStateException("[MEMBER-003] UPDATE ERROR");
            }

            ss.setAttribute("alertMsg", "회원수정가 완료되었습니다.");
            ss.removeAttribute("loginUser");
            return "redirect:/home";
        } catch(Exception e) {
            e.printStackTrace();
            return "redirect:error";
        }
    }

}
