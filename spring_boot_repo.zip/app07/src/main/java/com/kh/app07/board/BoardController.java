package com.kh.app07.board;

import com.kh.app07.member.MemberVo;
import org.springframework.ui.Model;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("board")
public class BoardController {

    @Autowired
    private BoardService boardService;


    @GetMapping("insert")
    public String insert(HttpSession ss){
        if(ss.getAttribute("loginUser") == null) {
            ss.setAttribute("alertMsg", "로그인이 필요합니다");
            return "/home";
        }

        return "board/insert";

    }

    @PostMapping("insert")
    public String insert(BoardVo vo, HttpSession ss) {

        try{
            MemberVo userVo = (MemberVo)ss.getAttribute("loginUser");
            vo.setWriterNo(userVo.getNo());
            int result = boardService.insert(vo);

            if(result != 1) {
                return "redirect:error";
            }
            return "redirect:list";
        } catch(Exception e) {
            e.printStackTrace();
            return "redirect:error";
        }
    }

    @GetMapping("list")
    public String list(HttpSession ss) {

        List<BoardVo> voList = boardService.list();

        ss.setAttribute("voList", voList);


        return "board/list";

    }

    @PostMapping("delete")
    public String delete(Model model, HttpSession ss, BoardVo vo) {

        String alertMsg = (String) ss.getAttribute("alertMsg");
        if(alertMsg != null) {
            model.addAttribute("alertMsg", alertMsg);
            ss.removeAttribute("alertMsg");
        }


        int result = boardService.delete(vo);

        if(result != 1) {
            throw new IllegalStateException("삭제오류에영");
        }

        ss.setAttribute("alertMsg","삭제가 완료되었습니다.");

        return "redirect:list";
    }






}
