const no = new URLSearchParams(window.location.search).get('no');

if (no) {
    fetch(`http://127.0.0.1:8080/api/board/${no}`)
        .then(resp => resp.json())
        .then(data => {
            // data를 사용해 상세 내용 표시
            const body = document.querySelector("body");
            const x = document.createElement("div")
            x.innerText = `${data.no} ${data.title} ${data.content} ${data.writerNo}`;
            body.appendChild(x);
        })
        .catch(err => console.error("에러 발생", err));
} else {
    alert("잘못된 접근입니다.");
}