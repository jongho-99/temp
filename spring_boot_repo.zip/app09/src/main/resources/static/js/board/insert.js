function f01() {
    const url = "http://127.0.0.1:8080/api/board/insert";

    const title = document.querySelector("#title").value;
    const content = document.querySelector("#content").value;

    const vo = {
        title,
        content
    }

    const option = {
        method : "POST",
        headers : {'Content-Type': 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option)
    .then(resp => resp.text())
    .then(data => {

        console.log(data);
        if(data == 1) {
            location.href= "http://127.0.0.1:8080/board/list"
        } else {
            alert("게시글 등록 실패");
            location.href="/home"
        }
    })
}
