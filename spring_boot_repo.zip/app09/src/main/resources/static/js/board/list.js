const url = "http://127.0.0.1:8080/api/board/list";

fetch(url)
.then(resp => resp.json())
.then(data => {

    const tbody = document.querySelector("#tb");
    if(data != null) {
        
        for(let vo of data) {
            let x = document.createElement("tr");
            x.innerHTML = `
            <input type="hidden" value=${vo.no}>
            <td>${vo.no}</td>
            <td>${vo.title}</td>
            <td>${vo.content}</td>
            <td>${vo.writeNo}</td>
            `

            tbody.appendChild(x);
        }

    } else {
        alert("게시글 등록 실패");
        location.href="/home"
    }
})

 const tr = document.querySelectorAll("tb tr");

 tr.forEach(element => {
     element.addEventListener('click', (e) => {

         const select = element.querySelector("input[type=hidden]");

         location.href = "http://127.0.0.1/api/board/" + select.value;


    

 })

})