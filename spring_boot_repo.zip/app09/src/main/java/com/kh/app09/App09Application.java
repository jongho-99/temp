package com.kh.app09;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App09Application {

	public static void main(String[] args) {
		SpringApplication.run(App09Application.class, args);
	}

}
