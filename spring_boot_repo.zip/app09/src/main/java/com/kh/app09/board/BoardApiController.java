package com.kh.app09.board;

import lombok.RequiredArgsConstructor;
import org.apache.ibatis.annotations.Delete;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {


    private final BoardService boardService;

    @PostMapping
    public int insert(@RequestBody BoardVo vo) {

        try{
            int result = boardService.insert(vo);

            if(result != 1) {
                throw new IllegalStateException("result가 1이 아님");
            }

            return result;

        } catch (Exception e) {
            return 0;
        }
    }

    @GetMapping("list")
    // 포스트맨으로 받을꺼임(JSON 타입으로)
    public List<BoardVo> list() {

        //데이터 싹다 가져와서 출력하기
        List<BoardVo> voList = boardService.list();

        return voList;


    }
    //경로변수 사용하기
    @GetMapping("{no}")
    public BoardVo detail(@PathVariable String no) {

        BoardVo vo = boardService.detail(no);
        return vo;
    }


    @DeleteMapping("{no}")
    public int delete(@PathVariable String no) {

        return boardService.delete(no);
    }

    //update
    @PutMapping("{no}")
    public int update(@RequestBody BoardVo vo, @PathVariable String no) {
        vo.setNo(no);
        return boardService.update(vo);
    }
}
