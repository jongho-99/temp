const url = "http://127.0.0.1:8080/api/board"

fetch(url)
.then(resp => resp.json())
.then(map => {

    const tb = document.querySelector("#tb");
    if(map != null) {
        const voList = map.voList;
        tb.innerHTML = "";
        for(let i of voList) {
            
            const tr = document.createElement("tr");
            tb.innerHTML += `
                <tr id ="trtr" onclick="location.href = '/board/detail/${i.no}'">
                    <td>글번호: ${i.no} </td>
                    <td>제목: ${i.title}</td>
                    <td>내용: ${i.content}</td>
                    <td>조회수: ${i.hit}</td>
                </tr>
            `

        }
    }
})


