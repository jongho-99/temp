const no = location.href.split("/").pop();
function selectOne(no) {
    // const no = location.href.split("/").pop();    
    const url =`http://127.0.0.1:8080/api/board/${no}`
    fetch(url)
    .then(resp => resp.json())
    .then(map => {

        const vo = map.vo;
        const title = document.querySelector("input[name=title]")
        const content = document.querySelector("textarea[name=content]")

        title.value = vo.title;
        content.value = vo.content;
    })
    .catch (err => {

        console.log(err);
        alert("상세조회 실패했어여 ㅠㅠ");
        location.href = "/board/list";
        
    })
}

function update() {

    const no = location.href.split("/").pop();
    const title = document.querySelector("input[name=title]").value;
    const content = document.querySelector("textarea[name=content]").value;

    const vo = {
        no,
        title,
        content,
    }
    const url = "http://127.0.0.1:8080/api/board"
    const option = {
        method : "PUT",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url, option)
    .then(resp => resp.json())
    .then(map => {
        const data = map.data;
        console.log(data);
        const msg = map.msg;

        if(data != 1) {
            alert("업데이트 실패 [data가 1이 아님..]")
        } else {
            alert("업데이트 성공이에여 !!!!!!!!!");
            location.href = "http://127.0.0.1:8080/board/list"
        }
    })
}

function del() {
    const no = location.href.split("/").pop();
    const vo = {
        no
    }
    const option = {
    method : "DELETE",
    headers : {
        'Content-Type' : 'application/json'
    },
    body : JSON.stringify(vo)
    }
    const url = "http://127.0.0.1:8080/api/board"

    fetch(url, option)
    .then(resp => resp.json())
    .then(map => {

        const result = map.result;
        const msg = map.msg;

        if(result != 1) {
            alert("삭제 실패 [data가 1이 아님..]")
        } else {
            alert("삭제 성공이에여 !!!!!!!!!");
            location.href = "http://127.0.0.1:8080/board/list"
        }
    })
}

selectOne(no);