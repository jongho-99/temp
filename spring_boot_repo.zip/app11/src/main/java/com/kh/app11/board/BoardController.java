package com.kh.app11.board;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("board")
public class BoardController {

    @GetMapping("insert")
    public void insert() {

    }

    @GetMapping("list")
    public void list(){

    }
    //게시물 목록에서 원하는 글 클릭하면 board/detail/??이동 하지만 일단 detail.jsp 포워딩
    // jsp 파일에는 js파일이 있으므로 js파일 실행
    //js에서 location.href.split("/").pop()을 통해서 ?? 값 가져와서 해당 페이지에 대해서 api 처리해서 데이터 가져옴
    @GetMapping("detail/*")
    public String detail() {
        return "/board/detail";
    }

}
