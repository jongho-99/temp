package com.kh.app11.board;


import lombok.RequiredArgsConstructor;
import org.apache.ibatis.annotations.Delete;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {

    private final BoardService boardService;


    @PostMapping
    public HashMap<String, String> insert(@RequestBody BoardVo vo) {
        vo.setWriterNo("1");
        int result = boardService.insert(vo);

        HashMap<String, String> map = new HashMap<>();
        map.put("result", result + "");

        if(result != 1) {
            map.put("status","result not 1");
        } else {
            map.put("status", "insert success!!!");
        }
        return map;
    }

    @GetMapping
    public HashMap<String, Object> list() {
        List<BoardVo> voList = boardService.list();

        HashMap<String, Object> map = new HashMap<>();
        map.put("voList", voList);

        if(voList == null) {
            map.put("status","voList is null...");
        } else {
            map.put("status", "list print success!!");
        }

        return map;
    }

    @GetMapping("{x}")
    public HashMap<String, Object> detail(@PathVariable String x) {

        BoardVo vo = boardService.detail(x);
        HashMap<String, Object> map = new HashMap<>();
        map.put("vo", vo);
        if(vo == null)
            map.put("status", "vo is null...");
        else
            map.put("status", "vo detail success !!!");
        System.out.println(x);
        System.out.println(vo);
        return map;
    }



    //수정하기
    @PutMapping
    private  Map<String, Object> update(@RequestBody BoardVo vo) {

        //어떤 번호에 대해서 수정되는건지 vo.setNo() 필요
        System.out.println("@@@@@@@@@ : " + vo);
        int result = boardService.update(vo);

        Map<String, Object> map = new HashMap<>();

        map.put("data", result);

        if(result != 1) {
            map.put("status", "result not 1");
        } else {
            map.put("status", "update success!!!");
        }

        System.out.println(map);

        return map;
    }

    @DeleteMapping
    public Map<String, Object> delete(@RequestBody Map<String, Object> reqMap) {

        int result = boardService.delete(reqMap.get("no"));

        Map<String, Object> map = new HashMap<>();
        map.put("result", result);

        if(result != 1) {
            map.put("msg", "result not 1");
        } else {
            map.put("msg", "delete success !!!!!!!!!");
        }

        System.out.println(result);
        return map;
    }

}
