package com.kh.app11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App11Application {

	public static void main(String[] args) {
		SpringApplication.run(App11Application.class, args);
	}

}
