package com.kh.app11.board;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
@Service
@RequiredArgsConstructor

//트랜잭션 처리에서 롤백이나 커밋담당을 위한 어노테이션 (메서드나 클래스)
@Transactional

public class BoardService {

    private final BoardMapper boardMapper;

    public int insert(BoardVo vo) {
        return boardMapper.insert(vo);
    }

    public List<BoardVo> list() {
        return boardMapper.list();
    }

    public BoardVo detail(String x) {
        boardMapper.increaseHit(x);
        return boardMapper.detail(x);
    }

    public int update(BoardVo vo) {
        return boardMapper.update(vo);
    }

    public int delete(Object no) {
        return boardMapper.delete(no);
    }
}
