console.log("gd");

const title = document.querySelector("input[name=title]");
const content = document.querySelector("textarea[name=content]");

function f01() {
    const url = "http://127.0.0.1:8080/api/board/insert"
    const vo = {
        title : title.value,
        content : content.value
    }
    const option = {
        method : 'POST',
        headers : {'Content-Type': 'application/json'},
        body : JSON.stringify(vo) ,
        
    };
    //컨트롤러에서 @responseBody로 프로미스 반환받음
    fetch(url, option)
    .then( resp => resp.text() )
    .then( data =>  {
       console.log(data);
       if(data == 1) {
            location.href="http://127.0.0.1:8080/board/list";


       }else {
        alert("작성실패 ㅋㅋ");
       }

    });

    
}