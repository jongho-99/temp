const url = "http://127.0.0.1:8080/api/board/list";
const tbody = document.querySelector("#board-tbody");

fetch(url)
  .then(resp => resp.json())
  .then(data => {
    console.log(data);

    if (data != null) {
      for (let i of data) {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${i.no}</td>
          <td>${i.title}</td>
          <td>${i.content}</td>
          <td>${i.writerNo}</td>
        `;
        tbody.appendChild(tr);
      }
    } else {
      alert("데이터가 없습니다.");
    }
  })
  .catch(error => {
    console.error("에러 발생:", error);
    alert("서버 통신 중 오류 발생");
  });