package com.kh.app08.board.controller;

import com.kh.app08.board.mapper.BoardMapper;
import com.kh.app08.board.service.BoardService;
import com.kh.app08.board.vo.BoardVo;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("board")
public class BoardController {

    @GetMapping("insert")
    public void insert() {}

    @GetMapping("list")
    public void list() {
    }




}
