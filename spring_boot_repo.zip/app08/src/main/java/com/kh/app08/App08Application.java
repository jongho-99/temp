package com.kh.app08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App08Application {

	public static void main(String[] args) {
		SpringApplication.run(App08Application.class, args);
	}

}
