package com.kh.app08.board.controller;

import com.kh.app08.board.service.BoardService;
import com.kh.app08.board.vo.BoardVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {

    private final BoardService boardService;

    @PostMapping("insert")
    public int insert(@RequestBody BoardVo vo) {
        System.out.println("BoardController.insert");
        System.out.println("vo = " + vo);

        vo.setWriterNo("1");

        try{
            int result = boardService.insert(vo);

            if(result != 1) {
                throw new IllegalStateException("result가 1이 아님");
            }

            return result;
        } catch (Exception e) {

            e.printStackTrace();
            return 0;
        }

    }

    @GetMapping("list")
    @ResponseBody
    public List<BoardVo> list(){

        List<BoardVo> voList = boardService.getBoardList();
        System.out.println("voList = " + voList);

        return voList;

    }

}
