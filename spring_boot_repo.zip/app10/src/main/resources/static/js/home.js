function insert() {

    const title = document.querySelector("input[name=title]").value;
    const content = document.querySelector("textarea[name=content]").value;

    const url = "http://127.0.0.1:8080/api/board/insert"

    const vo = {
        title,
        content
    }

    const option = {
        method : "POST",
        headers : {'Content-Type' : 'application/json'},
        body : JSON.stringify(vo)
    }

    fetch(url,option)
    .then(resp => resp.text())
    .then(data => {

        if(data != 1) {
            alert("게시물 등록 오류")
        } else {
            list();
            alert("게시물 작성 완료")
        }
    })
    
}

function list(pno = "1") {
    
    const url = `http://127.0.0.1:8080/api/board/list?pno=${pno}`

    const tb = document.querySelector("#tb")
    fetch(url)
    .then(resp => resp.json())
    .then(data => {

        if(data == null) {
            alert("리스트 출력 오류")
        } else {
            tb.innerHTML = "";
            for(let i of data.voList) {
                const tr = document.createElement("tr");
                tr.innerHTML = `
                <td>${i.no}</td>
                <td>${i.title}</td>
                <td>${i.content}</td>
                `
                tr.addEventListener("click", function () {
                    selectOne(i.no);
                })
                tb.appendChild(tr);
            }
        }

        createPageAreaBtn(data.pvo);
    })
}

function selectOne(no) {
    const url = `http://127.0.0.1:8080/api/board/${no}`
    fetch(url)
    .then(resp => resp.json())
    .then(data => {
        const select = document.querySelector("#select")
        select.innerHTML = `
        <h3>글번호: ${data.no}</h3>
        <h3>제목: ${data.title}</h3>
        <h3>작성자: ${data.writerNo}</h3>
        <h3>작성일시: ${data.createDate}</h3>
        <h3>조회수: ${data.hit}</h3>
        <h3>내용: ${data.content}</h3>
        `
    })
}

function createPageAreaBtn(pvo) {
    const PageArea = document.querySelector("#page-area");
    PageArea.innerHTML =""
    
    if(pvo.startPage != 1) {
        PageArea.innerHTML += `<button onclick="list(${pvo.startPage-1})">이전</button>`
    } else {
        PageArea.innerHTML += `<button onclick="list(${pvo.startPage})">이전</button>`
    }
    for(let i = pvo.startPage; i <= pvo.endPage; ++i) {
        if(pvo.currentPage == i) {
            PageArea.innerHTML += `<button disabled onclick="list(${i})">${i}</button>`
        } else {
        PageArea.innerHTML += `<button onclick="list(${i})">${i}</button>`
        }
    }
    if(pvo.endPage != pvo.maxPage) {
    PageArea.innerHTML += `<button onclick="list(${pvo.endPage+1})">다음</button>`
    }

}