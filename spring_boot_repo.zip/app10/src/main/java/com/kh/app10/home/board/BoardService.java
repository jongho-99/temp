package com.kh.app10.home.board;

import com.kh.app10.common.page.PageVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BoardService {

    private final BoardMapper boardMapper;

    public int insert(BoardVo vo) {
        return boardMapper.insert(vo);
    }

    public List<BoardVo> list(PageVo vo) {
        return boardMapper.list(vo);
    }

    public BoardVo select(String no) {
        int result = boardMapper.increaseHit(no);
        if(result != 1){
            throw new IllegalStateException();
        }
        return boardMapper.select(no);
    }

    public int getBoardCnt() {
        return boardMapper.getBoardCnt();
    }
}
