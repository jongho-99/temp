package com.kh.app10.home.board;

import com.kh.app10.common.page.PageVo;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("api/board")
@RequiredArgsConstructor
public class BoardApiController {

    private final BoardService boardService;

    @PostMapping("insert")
    public int insert(@RequestBody BoardVo vo){

        int result = boardService.insert(vo);

        Result rs = new Result();
        rs.setResult(result);

        if(result != 1) {
            rs.setStatus("baaaaaaaaaad");
        } else {
            rs.setStatus("gooooooooood");
        }

        return result;

    }

    @GetMapping("list")
    public HashMap<String, Object> list(@RequestParam(required = false, defaultValue = "1") int pno) {

        int listCount= boardService.getBoardCnt();
        int currentPage = pno;
        int pageLimit= 5;
        int boardLimit= 2;
        HashMap<String, Object> map = new HashMap<>();

        PageVo vo = new PageVo(listCount,currentPage,pageLimit,boardLimit);
        List<BoardVo> voList = boardService.list(vo);

        map.put("pvo", vo);
        map.put("voList" ,voList);

        return map;
    }

    @GetMapping("{no}")
    public BoardVo select(@PathVariable String no){

        BoardVo vo = boardService.select(no);

        return vo;
    }

//    @DeleteMapping("{no}")
//    public int delete(@PathVariable String no) {
//
////        int result = boardService.delete(no);
//
////        return result;
//    }
}

