package com.kh.app10.home.board;

import lombok.Data;

@Data
public class Result {
    int result;
    String status;

}
